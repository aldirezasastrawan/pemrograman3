<?php
$conn = mysql_connect('localhost', 'root', 'xxxxx') or die(mysql_error());
$db = mysql_select_db('latihan_android') or die(mysql_error());
?>